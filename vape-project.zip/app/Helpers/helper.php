//check admin or not
<?php

use App\Models\Admin;

class Helper{

}
