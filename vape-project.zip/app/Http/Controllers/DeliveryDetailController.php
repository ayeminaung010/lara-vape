<?php

namespace App\Http\Controllers;

use App\Models\DeliveryDetail;
use App\Http\Requests\StoreDeliveryDetailRequest;
use App\Http\Requests\UpdateDeliveryDetailRequest;

class DeliveryDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDeliveryDetailRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DeliveryDetail $deliveryDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DeliveryDetail $deliveryDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDeliveryDetailRequest $request, DeliveryDetail $deliveryDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DeliveryDetail $deliveryDetail)
    {
        //
    }
}
